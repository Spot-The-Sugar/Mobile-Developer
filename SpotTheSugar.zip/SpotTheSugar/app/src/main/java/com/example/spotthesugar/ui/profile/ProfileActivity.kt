package com.example.spotthesugar.ui.profile

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import com.example.spotthesugar.R
import com.example.spotthesugar.data.ResultState
import com.example.spotthesugar.data.pref.UserSharedPreference
import com.example.spotthesugar.databinding.ActivityProfileBinding
import com.example.spotthesugar.factory.ViewModelFactory

class ProfileActivity : AppCompatActivity() {

    private lateinit var binding:ActivityProfileBinding
    private val viewModel by viewModels<ProfileViewModel>{
        ViewModelFactory.getInstance()
    }
    private val prefs: UserSharedPreference by lazy {
        val sharedPreferences =
            getSharedPreferences(UserSharedPreference.SHARED_PREFS, Context.MODE_PRIVATE)
        UserSharedPreference(sharedPreferences)
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProfileBinding.inflate(layoutInflater)
        setContentView(binding.root)
        observeViewModel()
    }

    private fun observeViewModel(){
        val token = prefs.fetchAccessToken()
        viewModel.profile("Bearer ${token.toString()}").observe(this@ProfileActivity){
            result ->
                when(result){
                    is ResultState.Loading -> showLoading(true)
                    is ResultState.Error ->{
                        showLoading(false)
                        showToast(result.error)
                    }
                    is ResultState.Success -> {
                        showLoading(false)
                        result.data.let { profile ->
                            binding.profileNameDetail.text = profile?.userName.toString()
                            binding.profileEmailDetail.text = profile?.userEmail.toString()
                            binding.profileAge.text = profile?.userAge.toString()
                            binding.profileWeight.text = profile?.userWeight.toString()
                            binding.profileHeight.text = profile?.userHeight.toString()
                            binding.profileSugarLimit.text = profile?.sugarLimit.toString()
                        }
                    }
                }
        }
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun showLoading(isLoading: Boolean) {
        binding.progressIndicator.visibility = if (isLoading) View.VISIBLE else View.GONE
    }
}